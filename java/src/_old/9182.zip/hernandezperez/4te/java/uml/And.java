package uml;

public class And extends Component{
    public static final int A = 0;
    public static final int B = 1;
    public static final int X = 0;



    /**
     * Constructor for Components
     *
     * @param name Name of the Component
     */
    public And(String name) {
        super(name,2, 1);
        calc();
    }

    /**
     * Calculates the states of the output-ports
     */
    @Override
    public void calc() {
//        State state = super.getOutputPortState(X) ? State.ONE : State.ZERO;
        State state = State.ZERO;

        state = state.handleInput(super.in[A], super.in[B]);
        super.out[X] = state == State.ONE;
    }

    /**
     * State Machine of the FlipFlop
     */
    private enum State {
        ZERO {
            @Override
            State handleInput(boolean a, boolean b) {
                if (a && b) {
                    return ONE;
                }
                return ZERO;
            }
        },
        ONE {
            @Override
            State handleInput(boolean a, boolean b) {
                if (a && b) {
                    return ONE;
                }
                return ZERO;
            }
        };

        /**
         * handles the flipflop-states
         * @param a set-input
         * @param b reset-input
         * @return new state
         */
        abstract State handleInput(boolean a, boolean b);
    }
}
