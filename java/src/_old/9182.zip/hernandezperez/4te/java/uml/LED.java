package uml;

/**
 * @author Tobias Hernandez Perez
 */
public class LED extends Component{

    /**
     * LED-Constructor
     *
     * @param name Name of the LED
     */
    public LED(String name) {
        super(name, 1, 0);
    }

    @Override
    public void calc() {
        // nothing to do
    }
}
