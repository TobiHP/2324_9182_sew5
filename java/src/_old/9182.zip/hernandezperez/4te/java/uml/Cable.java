package uml;

/**
 * @author Tobias Hernandez Perez
 */
public class Cable {
    private String name;
    private Component src;
    private Component dst;
    private int srcPort;
    private int dstPort;

    /**
     * Cable-Constructor
     * @param name Name of the cable
     * @param src Source-Component
     * @param dst Destination-Component
     * @param srcPort Source-Port of the src
     * @param dstPort Destination-Port of the dst
     */
    public Cable(String name, Component src, Component dst, int srcPort, int dstPort) {
        this.name = name;
        this.src = src;
        this.dst = dst;
        this.srcPort = srcPort;
        this.dstPort = dstPort;
    }

    /**
     * Transmits the data between the two components
     */
    public void dispatch() {
        dst.setInputPortState(dstPort, src.getOutputPortState(srcPort));
    }
}
