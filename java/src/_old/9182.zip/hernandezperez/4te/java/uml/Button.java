package uml;

import java.util.TreeMap;

public class Button extends Component{
    /**
     * Button-Constructor
     * @param name Name of the button
     */
    public Button(String name) {
        super(name, 0, 1);
    }

    /**
     * Presses the button
     */
    public void press() {
        super.out[0] = true;;
    }

    /**
     * Releases the button
     */
    public void release() {
        super.out[0] = false;
    }

    /**
     * Sets the output state
     */
    @Override
    public void calc() {
        // nothing to do
    }
}
