package uml;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Tobias Hernandez Perez
 */
class UMLTests {
    Button buttonS = new Button("ButtonS");
    Button buttonR = new Button("ButtonR");

    FlipFlop flipFlop = new FlipFlop("FlipFlop");
    LED led = new LED("Led");

    Cable cableS = new Cable("ButtonS to FlipFlopS", buttonS, flipFlop, 0, 0);
    Cable cableR = new Cable("ButtonR to FlipFlopR", buttonR, flipFlop, 0, 1);
    Cable cableLED = new Cable("FlipFlopQ to LED", flipFlop, led, 0, 0);

    Cable[] cables = new Cable[]{cableS, cableR, cableLED};
    Component[] components = new Component[]{buttonS, buttonR, flipFlop, led};


    private void dispatch() {
        for (Cable c: cables) {
            c.dispatch();
        }
    }

    private void calc() {
        for (Component c: components) {
            c.calc();
        }
    }


    @Test
    public void testInit() {
        assertFalse(buttonS.out[0]);
        assertFalse(buttonR.out[0]);
        assertFalse(flipFlop.out[0]);
        assertTrue(flipFlop.out[1]);
        assertFalse(led.in[0]);
    }


    @Test
    public void testClick1() {
        buttonS.press();
        dispatch();
        calc();

        assertTrue(buttonS.out[0]);
        assertFalse(buttonR.out[0]);
        assertTrue(flipFlop.out[0]);
        assertFalse(flipFlop.out[1]);
        assertFalse(led.in[0]);
    }

    @Test
    public void testClick2() {
        buttonS.press();
        dispatch();
        calc();

        assertTrue(buttonS.out[0]);
        assertFalse(buttonR.out[0]);
        assertTrue(flipFlop.out[0]);
        assertFalse(flipFlop.out[1]);
        assertFalse(led.in[0]);

        buttonS.release();
        dispatch();
        calc();

        assertFalse(buttonS.out[0]);
        assertFalse(buttonR.out[0]);
        assertTrue(flipFlop.out[0]);
        assertFalse(flipFlop.out[1]);
        assertTrue(led.in[0]);
    }

    @Test
    public void testClick3() {
        buttonS.press();
        dispatch();
        calc();

        assertTrue(buttonS.out[0]);
        assertFalse(buttonR.out[0]);
        assertTrue(flipFlop.out[0]);
        assertFalse(flipFlop.out[1]);
        assertFalse(led.in[0]);

        buttonS.release();
        buttonR.press();
        dispatch();
        calc();

        assertFalse(buttonS.out[0]);
        assertTrue(buttonR.out[0]);
        assertFalse(flipFlop.out[0]);
        assertTrue(flipFlop.out[1]);
        assertTrue(led.in[0]);

        dispatch();
        calc();

        assertFalse(led.in[0]);
    }


    Button buttonA = new Button("ButtonA");
    Button buttonB = new Button("ButtonB");

    And and = new And("AND");
    LED led2 = new LED("Led2");

    Cable cableA = new Cable("ButtonA to ANDA", buttonA, and, 0, 0);
    Cable cableB = new Cable("ButtonB to ANDB", buttonB, and, 0, 1);
    Cable cableLED2 = new Cable("ANDX to LED", and, led2, 0, 0);

    Cable[] cables2 = new Cable[]{cableA, cableB, cableLED2};
    Component[] components2 = new Component[]{buttonA, buttonB, and, led2};



    private void dispatch2() {
        for (Cable c: cables2) {
            c.dispatch();
        }
    }

    private void calc2() {
        for (Component c: components2) {
            c.calc();
        }
    }
    @Test
    public void testInit2() {
        assertFalse(buttonA.out[0]);
        assertFalse(buttonB.out[0]);
        assertFalse(and.out[0]);
        assertFalse(led2.in[0]);
    }

    @Test
    public void testAnd() {
        buttonA.press();
        dispatch2();
        calc2();

        assertTrue(buttonA.out[0]);
        assertFalse(buttonB.out[0]);
        assertFalse(and.out[0]);
        assertFalse(led2.in[0]);

        buttonB.press();
        dispatch2();
        calc2();


        assertTrue(buttonA.out[0]);
        assertTrue(buttonB.out[0]);
        assertTrue(and.out[0]);
        assertFalse(led2.in[0]);

        dispatch2();
        calc2();

        assertTrue(led2.in[0]);

        buttonB.release();
        dispatch2();
        calc2();

        assertTrue(led2.in[0]);

        dispatch2();
        calc2();

        assertFalse(led2.in[0]);

    }

}