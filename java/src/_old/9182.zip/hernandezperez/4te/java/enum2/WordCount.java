// Tobias Hernandez Perez, 4CN

package enum2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class WordCount {
    int counter;

    /**
     * State Machine used to count the number of words in a string
     */
    private enum State {
        NOWORD {
            @Override
            State handleChar(char ch, WordCount context) {
                if (Character.isLetter(ch)) {
                    context.counter++;
                    return INWORD;
                } else if (ch == '<') {
                    return INTAG;
                }

                return NOWORD;
            }
        },
        INWORD {
            @Override
            State handleChar(char ch, WordCount context) {
                if (ch == '<') {
                    return INTAG;
                }
                else if (!Character.isLetter(ch)) {
                    return NOWORD;
                }

                return INWORD;
            }
        },
        INTAG {
            @Override
            State handleChar(char ch, WordCount context) {
                if (ch == '>') {
                    return NOWORD;
                }
                else if (ch == '\"') {
                    return INSTRING;
                }

                return INTAG;
            }
        },
        INSTRING {
            @Override
            State handleChar(char ch, WordCount context) {
                if (ch == '\"') {
                    return INTAG;
                }
                else if (ch == '\\') {
                    return IGNORE;
                }

                return INSTRING;
            }
        },
        IGNORE {
            @Override
            State handleChar(char ch, WordCount context) {
                return State.INSTRING;
            }
        };

        /**
         *
         * @param ch
         * @param context
         * @return
         */
        abstract State handleChar(char ch, WordCount context);
    }

    /**
     * counts the number of words in a string using enums
     * html tags are ignored
     * @param s string of words
     * @return number of words
     */
    public int count(String s) {
        State state = State.NOWORD;
        counter = 0;

        for (char c : s.toCharArray()) {
            state = state.handleChar(c, this);
        }

        return counter;
    }

    public static void main(String[] args) throws IOException {
        WordCount test = new WordCount();
        String text = String.valueOf(Files.readAllLines(Paths.get("/home/hp/Documents/Schule/4te_Klasse/SEW4/IntelliJ/res/crsto12.html")));
        System.out.println(test.count(text));
    }
}
