// Tobias Hernandez Perez, 4CN

package secondTry;

public class WordCount {
    private enum States {
        NOWORD,
        INWORD,
        INTAG,
        INSTRING,
        IGNORE
    }

    /**
     * counts the number of words in a string using enums
     * html tags are ignored
     * @param s string of words
     * @return number of words
     */
    public static int count(String s) {
        States state = States.NOWORD;

        int counter = 0;
        for (char ch : s.toCharArray()) {
            switch (state) {
                case NOWORD -> {
                    if (Character.isLetter(ch)) {
                        counter++;
                        state = States.INWORD;
                    } else if (ch == '<') {
                        state = States.INTAG;
                    }
                }
                case INWORD -> {
                    if (ch == '<') {
                        state = States.INTAG;
                    }
                    else if (!Character.isLetter(ch)) {
                        state = States.NOWORD;
                    }
                }
                case INTAG -> {
                    if (ch == '>') {
                        state = States.NOWORD;
                    }
                    else if (ch == '\"') {
                        state = States.INSTRING;
                    }
                }
                case INSTRING -> {
                    if (ch == '\"') {
                        state = States.INTAG;
                    }
                    else if (ch == '\\') {
                        state = States.IGNORE;
                    }
                }
                case IGNORE -> state = States.INSTRING;
            }
        }
        
        return counter;
    }
}
