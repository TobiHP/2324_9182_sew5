// Tobias Hernandez Perez, 4CN

package firsttry;

public class WordCount {
    /**
     * counts the number of words in a string
     * html tags are ignored
     * @param s string of words
     * @return number of words
     */
    public static int count(String s) {
        if (s.isBlank()) return 0;
        s = s.replaceAll("\\\\.", " ");
        s = s.replaceAll("\"<[^\"]*>", " ");
        s = s.replaceAll("\"<.*>\"", " ");
        s = s.replaceAll("<[^<>]*", " ");
        s = s.replaceAll("<[^<>]*>", " ");
        s = s.replaceAll("[^a-zA-Z]", " ");
        s = s.replaceAll(" +", " ");
        return s.trim().split("\\ ").length;
    }
}
