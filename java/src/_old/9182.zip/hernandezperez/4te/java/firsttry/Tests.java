package firsttry;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Tests {
        @Test
        public void testEmptyString() {
                assertEquals(0, WordCount.count("")); // Reihenfolge: expected, actual
                assertEquals(0, WordCount.count(" "));
                assertEquals(0, WordCount.count("  "));
        }

        @Test
        public void testOneWord() {
                assertEquals(1, WordCount.count("eins"));
                assertEquals(1, WordCount.count(" eins"));
                assertEquals(1, WordCount.count("eins "));
                assertEquals(1, WordCount.count(" eins "));
                assertEquals(1, WordCount.count(" eins  "));
                assertEquals(1, WordCount.count("  eins "));
                assertEquals(1, WordCount.count("  eins  "));
        }

        @Test
        public void testSpecialChar() {
                assertEquals(1, WordCount.count("eins:"));
                assertEquals(1, WordCount.count(":eins"));
                assertEquals(1, WordCount.count(":eins:"));
                assertEquals(1, WordCount.count(" eins  "));
                assertEquals(1, WordCount.count(" eins : "));
                assertEquals(1, WordCount.count(": eins :"));
                assertEquals(3, WordCount.count("ein erster Text"));
                assertEquals(3, WordCount.count(" ein  erster   Text      "));
                assertEquals(3, WordCount.count("ein:erster.Text"));
        }

        @Test
        public void testOneChar() {
                assertEquals(1, WordCount.count("a"));
                assertEquals(1, WordCount.count(" a"));
                assertEquals(1, WordCount.count("a "));
                assertEquals(1, WordCount.count(" a "));
        }

        @Test
        public void testHtmlBasic() {
                assertEquals(1, WordCount.count(" eins  <html> "));
                assertEquals(1, WordCount.count(" eins  < html> "));
                assertEquals(1, WordCount.count(" eins  <html > "));
                assertEquals(1, WordCount.count(" eins  < html > "));
                assertEquals(4, WordCount.count(" eins <html> zwei<html>drei <html> vier"));
        }

        @Test
        public void testHtmlEasy() {
                assertEquals(2, WordCount.count(" eins <html> zwei "));
                assertEquals(2, WordCount.count(" eins <html>zwei "));
                assertEquals(2, WordCount.count(" eins<html> zwei "));
                assertEquals(2, WordCount.count(" eins<html>zwei "));
                assertEquals(2, WordCount.count(" eins<img alt=\"xxx\" > zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"xxx yyy\" > zwei"));
        }

        @Test
        public void testHtmlMedium() {
                assertEquals(2, WordCount.count(" eins \"zwei\" "));
                assertEquals(2, WordCount.count(" eins\"zwei\" "));
                assertEquals(2, WordCount.count(" eins \"zwei\""));
                assertEquals(3, WordCount.count(" eins \"zwei\"drei"));
                assertEquals(3, WordCount.count(" eins \"zwei\" drei"));
        }

        @Test
        public void testHtmlIllegal() {
                assertEquals(1, WordCount.count(" eins<html")); // kein >
        }

        @Test
        public void testHtmlBild() {
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild>\" > zwei")); // <> innerhalb ""
                assertEquals(2, WordCount.count(" eins<img alt=\"bild>\" > zwei")); // <> innerhalb ""
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild>\" keinwort> zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild>\" src=\"bild.png\" >zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild\" keinwort>zwei"));
        }

        @Test
        public void testHtmlTricky() {
                assertEquals(1, WordCount.count(" eins<img alt=\"<bild\" keinwort"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild\" keinwort> zwei"));
                assertEquals(1, WordCount.count(" eins<img alt=\"<bild keinwort> keinwort"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild keinwort keinwort\">zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild keinwort< keinwort\">zwei"));
        }

        @Test
        public void testHtmlEvil() {
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild \\\" keinwort> keinwort\" keinwort>zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild \\\" keinwort<keinwort\" keinwort>zwei"));
                assertEquals(2, WordCount.count(" eins<img alt=\"<bild \\\" keinwort keinwort\" keinwort>zwei"));
        }

        @Test
        public void testHtmlFinal() {
                assertEquals(4, WordCount.count(" \\\"null\\\" eins<img alt=\"<bild \\\" keinwort keinwort\" keinwort>zwei \"drei\""));
        }
}