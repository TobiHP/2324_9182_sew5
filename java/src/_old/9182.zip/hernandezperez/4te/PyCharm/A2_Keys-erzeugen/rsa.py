import logging
import os.path
import random
import argparse

import miller_rabin as miller_rabin


def generate_keys(number_of_bits):
    """
    generates two rsa keys with a given number of bits
    using the miller rabin process for prime number generation
    :param number_of_bits: length of the keys
    :return:

    >>> import secrets
    >>> keysize = 512
    >>> e, d, n, len = generate_keys(keysize)
    >>> nums = [secrets.randbits(keysize-1) for x in range(1,50)]
    >>> for x in nums:
    ...     c = pow(x, e, n)
    ...     y = pow(c, d, n)
    ...     assert x == y
    """
    logging.debug("generating keys with length: " + str(number_of_bits))
    p = miller_rabin.generate_prime(number_of_bits // 2 + 1)
    q = miller_rabin.generate_prime(number_of_bits - p.bit_length() + 1)
    n = p * q
    d = False
    while not d:
        try:
            e = random.randrange(n // 2)
            d = pow(e, -1, (p - 1) * (q - 1))
        except ValueError:
            continue

    return e, d, n, n.bit_length()


def file2ints(file, block_size):
    """
    converts a given file to integers
    provides them as a generator object in blocks
    :param file: convertable file
    :param block_size: size of individual blocks
    :return:
    """
    with open(file, mode="rb") as f:
        read_blaock = True
        while read_block != b'':
            read_block = f.read(block_size)
            yield int.from_bytes(read_block, "little")


def crypt_block(int_block, key):
    """
    en- or decrypts a block of data
    :param int_block: data
    :param key: private or public key
    :return:
    """
    x, n = key
    return pow(int_block, x, n)


def write_file(name, data, mode):
    """
    writes a file
    :param name: name of new file
    :param data: data of new file
    :param mode: writing mode
    :return:
    """
    logging.debug("writing file: " + name)
    f = open(name, mode)
    f.write(data)
    f.close()


def encrypt(file):
    """
    encrypts a file with the public key
    :param file: file to encrypt
    :return:
    """
    if os.path.isfile(file):
        logging.debug("encrypting file: " + str(file))
    else:
        logging.error("encryption failed: File " + file + " does not exist")
        raise AttributeError("Error: File " + file + " does not exist")

    if os.path.isfile("pub.key"):
        with open("pub.key") as key:
            logging.debug("reading key: " + str(key.name))
            e = int(key.readline())
            n = int(key.readline())
            length = n.bit_length()
            block_size = (length - 1) // 8

            with open(file + ".encrypt", "wb") as f:
                f.write(int.to_bytes(crypt_block(os.path.getsize(file), (e, n)), block_size + 1, "little"))
                for block in file2ints(file, block_size):
                    data = crypt_block(block, (e, n))
                    f.write(int.to_bytes(data, block_size + 1, "little"))
                    # print(block)
                    # print(data)
    else:
        logging.debug("encryption failed: missing key file")
        raise AttributeError("Error: Missing key")


def decrypt(file):
    """
    decrypts a file with the private key
    :param file: encrypted file
    :return:
    """
    if os.path.isfile(file):
        logging.debug("decrypting file: " + str(file))
    else:
        logging.error("decryption failed: File " + file + " does not exist")
        raise AttributeError("Error: File " + file + " does not exist")

    if os.path.isfile("priv.key"):
        with open("priv.key") as key:
            logging.debug("reading key: " + str(key.name))
            d = int(key.readline())
            n = int(key.readline())
            length = n.bit_length()
            block_size = (length - 1) // 8

            with open(file + ".decrypt", "wb") as f:
                blocks = file2ints(file, block_size + 1)
                cur_block = next(blocks)
                file_size = crypt_block(cur_block, (d, n))
                for block in blocks:
                    data = crypt_block(block, (d, n))
                    f.write(int.to_bytes(data, block_size, "little"))
                f.truncate(file_size)
    else:
        logging.debug("decryption failed: missing key file")
        raise AttributeError("Error: Missing key")


def keygen(bits):
    """
    generates a key pair
    :param bits: key length
    :return:
    """
    e, d, n, length = generate_keys(bits)
    write_file("priv.key", str(e) + "\n" + str(n) + "\n" + str(length), "w")
    write_file("pub.key", str(d) + "\n" + str(n) + "\n" + str(length), "w")


def parse_args():
    """
    configures argparse
    :return:
    """
    parser = argparse.ArgumentParser(description="Generate RSA keys and encrypt/decrypt files.")
    parser.add_argument('-v', "--verbosity", help="increase output verbosity", action="store_true")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-k", "--keygen", type=int, help="generate new keys with the given length")
    group.add_argument("-e", "--encrypt", type=str, help="encrypt file")
    group.add_argument("-d", "--decrypt", type=str, help="decrypt file")

    args = parser.parse_args()

    if args.verbosity:
        print("verbosity turned on")
        logging.basicConfig(level=7)
    # e, d, n, length = False
    if args.keygen:
        keygen(args.keygen)
    if args.encrypt:
        encrypt(args.encrypt)
    if args.decrypt:
        decrypt(args.decrypt)


if __name__ == '__main__':
    # e, d, n, length = generate_keys(512)
    # print(length)
    # enc = crypt_block(735, (e, n))
    # print(enc)
    # dec = crypt_block(enc, (d, n))
    # print(dec)

    parse_args()

# TODO DOCS/TESTS
