import math
import time


def primes():
    """
    calculates all prime numbers
    :return: the next prime number
    >>> prime_nums = []
    >>> for _, prime in zip(range(5), primes()): prime_nums.append(prime)
    >>> print(prime_nums)
    [2, 3, 5, 7, 11]
    """
    yield from primes.cache
    p = primes.cache[-1]+2
    while True:
        if is_prime(p):
            primes.cache.append(p)
            yield p
        p += 2

primes.cache = [2, 3]


def is_prime(n):
    """
    checks whether a given number is a prime number
    :param n: prime number?
    :param cache: known primes
    :return:
    >>> is_prime(11)
    True
    >>> is_prime(13)
    True
    """
    for i in primes():
        if i * i > n:
            break
        if n % i == 0:
            return False
    return True


# test the runtime
if __name__ == '__main__':
    print(is_prime(1234567899876543212345678987623467898754323456789876543277777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777))

    # prims = []
    # for x in primes():
    #     prims.append(x)
    #     print(prims)

    # for z in [200_000, 400_000, 400_000]:
    #     begin = time.time()
    #     for _, prime in zip(range(z), primes()):
    #         x = prime
    #     end = time.time()
    #     print(f"{z}-te primzahl: {x} => {end - begin: 2}s")
