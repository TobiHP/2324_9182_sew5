# Tobias Hernandez Perez, 4CN
import functools


@functools.total_ordering
class Fraction:
    """ Fraction Class
    >>> f1 = Fraction(1,2)
    >>> f1 # __repr__
    Fraction(1, 2)
    >>> print(f1) # __str__
    1/2
    >>> f2 = Fraction(1,4)
    >>> print(f2)
    1/4
    >>> f1+f2
    Fraction(3, 4)
    >>> f1 + 1
    Fraction(3, 2)
    >>> 1 + f1
    Fraction(3, 2)
    >>> f1 - f2
    Fraction(1, 4)
    >>> f1 - 1
    Fraction(-1, 2)
    >>> 1 - f1
    Fraction(1, 2)
    >>> f1 * f2
    Fraction(1, 8)
    >>> f1 * 2
    Fraction(1, 1)
    >>> f1 / f2
    Fraction(2, 1)
    >>> f1 / 2
    Fraction(1, 4)
    >>> 2/f1
    Fraction(4, 1)

    >>> f1 > f2
    True
    >>> 2 > f1
    True
    >>> f1 == f2
    False
    >>> f1 == 1
    False
    >>> f1+2*f2 == 1
    True

    >>> print(3 + 1 / (7 + Fraction(1, 15)))
    3 15/106
    >>> f2 = Fraction(1,4)
    >>> print(f2)
    1/4
    >>> f3 = Fraction(3,4)
    >>> print(f3 + f2)
    1
    >>> print(f3 + Fraction(2,5))
    1 3/20
    >>> print(5 + Fraction(3,8))
    5 3/8
    >>> print(f3 - f2)
    1/2
    >>> print(Fraction(6,8) - f2)
    1/2
    >>> print(3 - f3)
    2 1/4
    >>> print(f3 * f2)
    3/16
    >>> print(8 * Fraction(103, 303))
    2 218/303
    >>> print(f3 / Fraction(38, 18))
    27/76
    >>> print(192 / Fraction(220, 17))
    14 46/55
    >>> print(float(f3))
    0.75
    >>> print(float(Fraction(17,20)))
    0.85
    >>> Fraction(1,7) == Fraction(2,14)
    True
    >>> Fraction(27,30) > Fraction(38,40)
    False
    >>> Fraction(12,4) < 5
    True
    >>> Fraction(12,4) >= 3
    True
    >>> Fraction(2,4) <= 2
    True
    >>> print(Fraction(-5, 3))
    -1 2/3
    >>> Fraction(1,2)/0
    Traceback (most recent call last):
      File "/opt/pycharm-eap/plugins/python/helpers/pycharm/docrunner.py", line 138, in __run
        exec(compile(example.source, filename, "single",
      File "<doctest Fraction[45]>", line 1, in <module>
        Fraction(1,2)/0
      File "/home/hp/Documents/Schule/4te_Klasse/SEW4/PyCharm/D2_Bruch/Fraction.py", line 263, in __truediv__
        return self * Fraction(other.denominator, other.numerator)
      File "/home/hp/Documents/Schule/4te_Klasse/SEW4/PyCharm/D2_Bruch/Fraction.py", line 117, in __init__
        raise ArithmeticError("can't divide by 0!")
    ArithmeticError: can't divide by 0!

    >>> Fraction(2,4)
    Fraction(1, 2)

    >>> a = Fraction(4,5); a.numerator = 6 # doctest: +ELLIPSIS +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    ...
    AttributeError: can't set attribute
    >>> Fraction(1_000_000_000_000_000_001, 1_000_000_000_000_000_000) > 1
    True
    >>> Fraction(1_000_000_000_000_000_001, 1_000_000_000_000_000_000) == 1
    False
    """

    _numerator = 0
    _denominator = 1

    """
    fraction constructor
    default values for numerator is 0, for denominator 1
    in case of division by 0 => raises error
    """

    def __init__(self, numerator=0, denominator=1):
        self._numerator = int(numerator)
        self._denominator = int(denominator)
        if self.denominator == 0:
            raise ArithmeticError("can't divide by 0!")
        if self.denominator < 0:
            self._numerator *= -1
            self._denominator *= -1
        self.reduce()

    """
    property used to get private _numerator
    """

    @property
    def numerator(self):
        return self._numerator

    """
    property used to get private _denominator
    """

    @property
    def denominator(self):
        return self._denominator

    """
    returns the greatest common divisor
    """

    def gcd(self):
        a = self.numerator
        b = self.denominator
        if a == 0:
            return abs(b)

        while b != 0:
            temp = a % b
            a = b
            b = temp

        return abs(a)

    """
    reduces the fraction to the lowest possible
    5/25 => 1/5
    """

    def reduce(self):
        gcd = self.gcd()
        self._numerator = self.numerator // gcd
        self._denominator = self.denominator // gcd

    """
    adds two fractions
    in case of int => converts to fraction
    1/5 + 1/5 = 2/5
    1/2 + 1/4 = 3/4
    1/2 + 1 = 3/2
    """

    def __add__(self, other):
        if isinstance(other, int):
            other = Fraction(other)

        if isinstance(other, Fraction):
            return Fraction((self.numerator * other.denominator) + other.numerator * self.denominator,
                            self.denominator * other.denominator)

        return NotImplemented

    """
    in case the fraction is on the right side of he addition
    same as __add__
    1 + 1/2 = 3/2
    """

    def __radd__(self, other):
        return self + other

    """
    subtracts two fractions
    in case of int => converts to fraction
    1/5 - 1/5 = 0
    1/2 - 1/4 = 1/4
    1/2 - 1 = -1/2
    """

    def __sub__(self, other):
        return self + other * -1

    """
    in case the fraction is on the right side of the subtraction
    1 - 1/2 = 1/2
    """

    def __rsub__(self, other):
        return self * -1 + other

    """
    multiplies two fractions
    in case of int => converts to fraction
    1/5 * 1/2 = 1/10
    1/2 * 5/4 = 5/8
    2/3 * 2 = 4/3
    """

    def __mul__(self, other):
        if isinstance(other, int):
            other = Fraction(other)
        if isinstance(other, Fraction):
            return Fraction(self.numerator * other.numerator, self.denominator * other.denominator)

        return NotImplemented

    """
    in case the fraction is on the right side of the multiplication
    same as __mul__
    2 * 2/3 = 4/3
    """

    def __rmul__(self, other):
        return self * other

    """
    divides two fractions
    in case of int => converts to fraction
    1/5 / 1/2 = 2/5
    1/2 / 1/4 = 2
    1/2 / 2 = 1/4
    """

    def __truediv__(self, other):
        if isinstance(other, int):
            other = Fraction(other)
        if isinstance(other, Fraction):
            return self * Fraction(other.denominator, other.numerator)

        return NotImplemented

    """
    in case the fraction is on the right side of the division
    2 / 2/3 = 3
    """

    def __rtruediv__(self, other):
        return Fraction(self.denominator, self.numerator) / Fraction(other.denominator, other.numerator)

    """
    converts a fraction to a float
    1/2 = 0.5
    """

    def __float__(self):
        return float(self.numerator / self.denominator)

    """
    checks whether one fraction is less than the other
    1/4 < 1/2 => True
    1/16 < 1/32 => False
    1/2 < 1 => True
    """

    def __lt__(self, other):
        if isinstance(other, int):
            other = Fraction(other)
        return (self.numerator * other.denominator) < (other.numerator * self.denominator)

    """
    checks whether two fraction have the same value
    1/2 == 1/2 => True
    1/2 == 0.5 => True
    1/2 == 1/3 => False
    """

    def __eq__(self, other):
        if isinstance(other, int):
            other = Fraction(other)
        return (self.numerator * other.denominator) == (other.numerator * self.denominator)

    """
    converts the fraction to a string
    Fraction(1,2) => 1/2
    Fraction(5,2) => 2 1/2
    """

    def __str__(self):
        numerator = self.numerator
        denominator = self.denominator
        if numerator == denominator:
            return str(1)
        elif denominator == 1:
            return str(numerator)
        elif abs(numerator) > denominator:
            return str(int(numerator / denominator)) + " " + str(abs(numerator) % denominator) + "/" + str(
                denominator)
        return str(numerator) + "/" + str(denominator)

    """
    prints the fraction itself
    Fraction(1,2) => Fraction(1,2)
    """

    def __repr__(self):
        return f'Fraction{self.numerator, self.denominator}'