import numpy as np

name = "res/day3"

def part1():
    handle = open(name)
    input = list()
    for line in handle:
        lineArray = list(line[:len(line) - 1])
        input.append(lineArray)

    npArray = np.array(input)
    bits = dict()
    gamma = list()
    for i in range(len(npArray[0])):
        for b in npArray[:, i]:
            bits[b] = bits.get(b, 0) + 1
        gamma.append(0 if (int(bits["0"]) > int(bits["1"])) else 1)
        bits.clear()

    epsilon = [i ^ 1 for i in gamma]
    return int("".join(str(i) for i in gamma), 2) * int("".join(str(i) for i in epsilon), 2)


if __name__ == '__main__':
    print("part1: ", part1())
    # print("part2: ", part2())
