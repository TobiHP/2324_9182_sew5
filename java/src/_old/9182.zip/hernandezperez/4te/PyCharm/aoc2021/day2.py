name = "res/day2"

def part1():
    handle = open(name)
    pos = dict()

    for line in handle:
        split = line.split()
        pos[split[0]] = pos.get(split[0], 0) + int(split[1])

    return pos["forward"] * (pos["down"] - pos["up"])

def part2():
    handle = open(name)
    vals = dict()
    pos = dict()

    for line in handle:
        split = line.split()
        key = split[0]
        val = int(split[1])
        vals[key] = vals.get(key, 0) + val
        aim = vals.get("down", 0) - vals.get("up", 0)

        if key == "forward":
            pos["horizontal"] = val + pos.get("horizontal", 0)
            pos["depth"] = val * aim + pos.get("depth", 0)

    return pos["horizontal"] * pos["depth"]



if __name__ == '__main__':
    print("part1: ", part1())
    # print("part2: ", part2())