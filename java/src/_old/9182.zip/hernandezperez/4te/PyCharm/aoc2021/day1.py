name = "res/day1"

def part1():
    handle = open(name)
    count = -1
    prevLine = "0"

    for line in handle:
        if int(line) > int(prevLine):
            count += 1
        prevLine = line

    return count


def part2():
    handle = open(name)
    count = 0
    curWindow = list()

    for line in handle:
        iLine = int(line)
        prevWindow = curWindow
        curWindow = curWindow[-2:]
        curWindow.append(iLine)

        if len(prevWindow) == 3:
            if sum(curWindow) > sum(prevWindow):
                count += 1


    return count



if __name__ == '__main__':
    # print("part1: ", part1())
    print("part2: ", part2())