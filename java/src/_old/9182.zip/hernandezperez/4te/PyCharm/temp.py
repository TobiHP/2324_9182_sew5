import re

name = input("Enter file:")
if len(name) < 1:
    name = "regex_sum_1648573.txt"
handle = open(name)

total = 0
for line in handle:
    for n in re.findall('[0-9]+', line):
        total += int(n)

print(total)