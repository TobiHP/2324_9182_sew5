# nur ungerade zahlen verwenden
# for p in {2, 3, 5, 7, 11, 9, 15, 997, 550, *list(range(550, 570)), 6601, 8911}:
#     nums = dict()
#     total = 0
#     ones = 0
#     for n in range(1, p-1):
#         x = pow(n, p-1, p)
#         nums[x] = nums.get(x, 0) + 1
#     # print(nums)
#     for val in nums.values():
#         total += val
#     if 1 in nums.keys():
#         print(p, ":", round(nums[1]*100/total), "%")
#     else:
#         print(p, ":", 0, "%")

##################something
def primes(amount):
    """
    calculates 'amount' prime numbers
    :param amount: number of primes zu calculate
    :return: prime number
    """
    yield 2
    p = 3
    counter = 0
    while True:
        nums = dict()
        total = 0
        for n in range(1, p - 1):
            x = pow(n, p - 1, p)
            nums[x] = nums.get(x, 0) + 1

        for val in nums.values():
            total += val

        if 1 in nums.keys():
            if nums[1] * 100 / total == 100:
                counter += 1
                yield p

        if counter == amount:
            break
        p += 2


for n in primes(10):
    print(n)
#########################33