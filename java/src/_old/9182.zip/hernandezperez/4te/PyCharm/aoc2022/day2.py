name = "res/day2"

def part1():
    handle = open(name)
    score = 0
    for line in handle:
        line = line.split()
        match line[1]:
            case "X":
                score += 1
                match line[0]:
                    case "A": score += 3
                    case "C": score += 6
            case "Y":
                score += 2
                match line[0]:
                    case "A": score += 6
                    case "B": score += 3
            case "Z":
                score += 3
                match line[0]:
                    case "B": score += 6
                    case "C": score += 3

    return score


def part2():
    handle = open(name)
    score = 0
    for line in handle:
        line = line.split()

        match line[0]:

            case "A":
                match line[1]:
                    case "X": score += 3
                    case "Y": score += 4
                    case "Z": score += 8
            case "B":
                match line[1]:
                    case "X": score += 1
                    case "Y": score += 5
                    case "Z": score += 9
            case "C":
                match line[1]:
                    case "X": score += 2
                    case "Y": score += 6
                    case "Z": score += 7
    return score


if __name__ == '__main__':
    print("part1: ", part1())
    print("part2: ", part2())