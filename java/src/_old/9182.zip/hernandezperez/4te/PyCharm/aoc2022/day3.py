name = "res/day3"

def part1():
    handle = open(name)
    res = 0

    for line in handle:
        firstHalve, secondHalve = line[:len(line) // 2], line[len(line) // 2:]

        for c in firstHalve:
            if secondHalve.find(c) != -1:
                res += ord(c) - 38 if c.isupper() else ord(c) - 96
                break

    return res


def part2():
    handle = open(name)
    res = 0
    group = list()

    for line in handle:
        group.append(line)
        if len(group) == 3:
            for c in group[0]:
                if group[1].find(c) != -1 and group[2].find(c) != -1:
                    res += ord(c) - 38 if c.isupper() else ord(c) - 96
                    break
            group = list()

    return res


if __name__ == '__main__':
    # print("part1: ", part1())
    print("part2: ", part2())