import numpy as np

name = "res/day8Test"


def parts():
    handle = open(name)
    lines = handle.readlines()
    trees = list()

    for line in lines:
        chars = [c for c in line if c != "\n"]
        trees.append(chars)
    trees = np.array(trees)

    print(trees)

    inSight = True
    for i in range(len(trees)):
        if i != 0 and i != len(trees) - 1:
            for j in range(len(trees[i])):
                if j != 0 and j != len(trees[i]) - 1:
                    for n in trees[i]:
                        if n > trees[i][j]:
                            inSight = False
                            break
                    for n in range(len(trees)):
                        for m in range(len(trees[n])):
                            if m == j and trees[n][m] > trees[i][j]:
                                inSight = False
                                break
                    if inSight:
                        print(trees[i][j])
                    inSight = True


    return


if __name__ == '__main__':
    print("part1: ", parts())
    # print("part2: ", parts(14))
