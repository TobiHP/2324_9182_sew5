import re

from anytree import Node, RenderTree


name = "res/day7"
nodes = dict()
sizes = dict()

def part1():
    handle = open(name)

    nodes["/"] = Node("")
    isList = False
    wd = nodes["/"]
    for line in handle:
        split = line.split()
        if line.startswith("$"):
            match split[1]:
                case "cd":
                    # print(str(wd.path).replace("Node", "").replace(",", ""))
                    # path = str(wd.path[-1]).split("'")[1] + "/" + split[2]
                    path = re.sub("dir|Node|[()', \"\[\]]", "", str(wd.path)) + "/" + split[2]
                    if split[2] == '..':
                        wd = wd.parent
                    elif split[2] == '/':
                        wd = wd.root
                    else:
                        wd = nodes[path]
                    isList = False
                case "ls":
                    isList = True
        elif isList:
            # path = str(wd.path[-1]).split("'")[1] + "/" + split[1]
            parent = re.sub("dir|Node|[()', \"\[\]]", "", str(wd.path))
            path = parent + "/" + split[1]
            file = [split[0], split[1]]
            nodes[path] = Node(file, parent=wd)
            if wd.name:
                sizes[parent] = sizes.get(parent, 0)
                if split[0] != "dir":
                    sizes[parent] = sizes.get(parent) + int(split[0])

    # for pre, fill, node in RenderTree(nodes["/"]):
    #     print("%s%s" % (pre, node.name))

    print(sizes)
    getSize()
    print(sizes)

    total = 0
    for size in sizes.values():
        if size <= 100000:
            total += size
    print(total)



def getSize():
    for node in nodes.values():
        nodeName = node.name
        if nodeName and node.parent.name and nodeName[0] == "dir":
            curDir = re.sub("dir|Node|[()', \"\[\]]", "", str(node.path))
            parent = re.sub("dir|Node|[()', \"\[\]]", "", str(node.parent.path))
            sizes[parent] = sizes.get(parent) + sizes.get(curDir, 0)



if __name__ == '__main__':
    # test()
    part1()
