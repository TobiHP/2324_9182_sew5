name = "res/day4"


def part1Old():
    handle = open(name)
    pairs = list()
    for line in handle:
        pair = line.splitlines()[0].split(",")
        pair[0] = pair[0].split("-")
        pair[1] = pair[1].split("-")

        s = list()
        for elf in pair:
            elfString = ""
            for i in range(int(elf[0]), int(elf[1]) + 1):
                elfString += str(i)
            s.append(elfString)
        pairs.append(s)

    count = 0
    for p in pairs:
        if p[0].find(p[1]) != -1 or p[1].find(p[0]) != -1:
            print(p)
            count += 1

    return count


def part1():
    handle = open(name)
    count = 0
    for line in handle:
        pair = line.splitlines()[0].split(",")
        first = pair[0].split("-")
        second = pair[1].split("-")

        if int(first[0]) <= int(second[0]) and int(first[1]) >= int(second[1]):
            count += 1
        elif int(first[0]) >= int(second[0]) and int(first[1]) <= int(second[1]):
            count += 1

    return count


def part2():
    handle = open(name)
    count = 0
    lineNum = 0
    for line in handle:
        pair = line.splitlines()[0].split(",")
        first = pair[0].split("-")
        second = pair[1].split("-")

        if int(second[0]) > int(first[1]) or int(first[0]) > int(second[1]):
            count += 1
        lineNum += 1

    return lineNum - count


if __name__ == '__main__':
    # print("part1: ", part1())
    print("part2: ", part2())
