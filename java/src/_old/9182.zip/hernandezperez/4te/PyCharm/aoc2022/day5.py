import numpy as np
import re

name = "res/day5"

def parts(part):
    handle = open(name)
    instructions = False

    crates = list()
    crateMap = dict()
    for line in handle:
        if line == "\n":
            crateArray = np.array(crates)
            for i in range(len(crateArray)+1):
                crateMap[i+1] = list(crateArray[:, i])
            instructions = True

            for key in crateMap:
                crateMap[key] = [i for i in crateMap.get(key) if i != "[_]"]
        elif line.find("1   2") != -1:
            continue
        elif instructions:
            instruct = re.findall("[0-9]+", line)
            fromEntry = crateMap.get(int(instruct[1]))
            toEntry = crateMap.get(int(instruct[2]))
            for i in range(int(instruct[0])):
                toEntry.insert(0 if part == 1 else i, fromEntry[0])
                fromEntry.remove(fromEntry[0])
        else:
            line = line.strip("\n").replace("    ", " [_] ").split()
            crates.append(line)

    res = ""
    for key in crateMap:
        res = res + str(crateMap.get(key)[0]).replace("[", "").replace("]", "")

    return res


if __name__ == '__main__':
    print("part1: ", parts(1))
    print("part2: ", parts(2))
