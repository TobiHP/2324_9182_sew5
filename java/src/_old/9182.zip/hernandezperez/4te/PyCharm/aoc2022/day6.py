name = "res/day6"

def parts(makerLen):
    handle = open(name)
    line = handle.readline()
    index = 0
    marker = ""

    for c in line:
        if len(marker) == makerLen:
            return index
        if marker.find(c) == -1:
            marker += c
        else:
            marker = marker[marker.find(c)+1:] + c
        index += 1

    return


if __name__ == '__main__':
    print("part1: ", parts(4))
    print("part2: ", parts(14))
