# file of calories carried by elves
name = "res/day1"

# get the elf who's carrying the most calories
def part1():
    handle = open(name)

    maxCal = 0
    sumCal = 0
    for line in handle:
        # print(line)
        if line == "\n":
            if sumCal > maxCal:
                maxCal = sumCal
            sumCal = 0
        else:
            sumCal += int(line)

    print(maxCal)


def part2():
    handle = open(name)

    calist = list()
    sumCal = 0
    for line in handle:
        if line == "\n":
            calist.append(sumCal)
            sumCal = 0
        else:
            sumCal += int(line)

    print(sum(sorted(calist, reverse=True)[:3]))



if __name__ == '__main__':
    part2()