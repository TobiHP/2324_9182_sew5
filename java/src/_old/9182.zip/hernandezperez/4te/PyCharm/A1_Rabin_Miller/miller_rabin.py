import random

cache = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103,
         107, 109,
         113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229,
         233, 239,
         241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367,
         373, 379,
         383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503,
         509, 521,
         523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653,
         659, 661,
         673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821,
         823, 827,
         829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977,
         983, 991,
         997]


def is_prime(n):
    """
    check whether a number is a prime number
    by first checking whether it's dividable by known primes
    and then using the miller rabin test
    :param n: number to test
    :return:
    """
    for p in cache:
        if n % p == 0:
            return False

    return is_prim_millerrabin(n)


def is_prim_millerrabin(number, anzahl=20):
    """
    check whether a number is a prime
    using the miller rabin test
    :param number: number to check
    :param anzahl: now many times the test should be repeated
    :return:
    """
    r, d = calc_rd(number)
    # n = pow(2, r) * d + 1
    for i in range(0, anzahl):
        a = random.randrange(2, number - 2)
        x = pow(a, d, number)
        if x == 1 or x == number - 1:
            continue
        for j in range(0, r - 1):
            x = pow(x, 2, number)
            if x == number - 1:
                break
        else:
            return False
    return True


def calc_rd(number):
    """
    calculate r and d for the miller rabin test
    :param number: number to test
    :return:
    """
    number = number - 1
    counter = 0
    while number % 2 == 0:
        number //= 2
        counter += 1
    return counter, number


def generate_prime(bits):
    """
    generates a prime number with a certain amount of bits
    :param bits: amount of bits
    :return:
    """
    max_value = (1 << bits) - 1
    p = random.randrange(max_value // 2, max_value, 2) | 1

    while True:
        if is_prime(p):
            cache.append(p)
            return p
        p += 2


# print(is_prime(1234567899876543212345678987623467898754323456789876543277777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777))
# print(is_prime(531137992816767098689588206552468627329593117727031923199444138200403559860852242739162502265229285668889329486246501015346579337652707239409519978766587351943831270835393219031728127))


def first_prime(bits):
    """
    generates a prime number with a certain amount of bits
    :param bits: amount of bits
    :return:
    >>> print(first_prime(512))
    13407807929942597099574024998205846127479365820592393377723561443721764030073546976801874298166903427690031858186486050853753882811946569946433649006084171
    """
    p = (1 << bits) - 1

    while True:
        if is_prime(p):
            cache.append(p)
            return p
        p += 2


if __name__ == '__main__':
    n = 191926127353949
    print(is_prime(n))
    n_bits = f'{n:08b}'
    counter = 0

    for i in n_bits:
        if counter == 12:
            counter = 0
            print()
        print(i, end='')
        counter += 1
