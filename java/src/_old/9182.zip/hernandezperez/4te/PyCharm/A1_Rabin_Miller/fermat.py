for p in {2, 3, 5, 7, 11, 9, 15, 997, 550, *list(range(550, 570)), 6601, 8911}:
    nums = dict()
    total = 0
    ones = 0
    for n in range(1, p):
        x = pow(n, p-1, p)
        nums[x] = nums.get(x, 0) + 1
    # print(nums)
    for val in nums.values():
        total += val
    if 1 in nums.keys():
        print(p, "->", round(nums[1]*100/total), "%")
    else:
        print(p, "->", 0, "%")
