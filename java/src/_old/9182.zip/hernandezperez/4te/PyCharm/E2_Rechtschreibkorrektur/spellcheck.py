# Tobias Hernandez Perez, 4CN
import string


def split_word(word):
    """
    splits a word in all its possibilities
    turns it to lower case
    >>> split_word("abc")
    [('', 'abc'), ('a', 'bc'), ('ab', 'c'), ('abc', '')]

    :param word: a given word string
    :return: split version as list
    """
    word = word.lower()
    return [(word[:i], word[i:])
            for i in range(len(word) + 1)]


def edit1(word):
    """
    tries to correct all possible typos in a word
    edit-distance 1

    :param word: word to find typos
    :return: all possible words with edit-distance 1 of word
    """
    split = split_word(word)
    alts = set()
    for head, tail in split:
        for c in string.ascii_lowercase:
            alts.add(head + c + tail)  # insert char
            alts.add(head + c + tail[1:])  # replace char
            alts.add(head + tail[1:])  # remove char
        if len(tail) >= 2:
            alts.add(head + tail[1] + tail[0] + tail[2:])  # swap chars
    return alts


def edit1_good(word, all_words):
    """
    finds matches for all results in edit1 of a word in all_words

    :param word: word to find corrections
    :param all_words: a set of all words in the dictionary
    :return: words that occur in both edit1(word) and all_words
    """
    return edit1(word) & all_words


def edit2_good(word, all_words):
    """
    finds matches for all results in edit1 of a word in all_words
    edit-distance 2

    :param word: word to find corrections
    :param all_words: a set of all words in the dictionary
    :return:  words that occur in both all possible words with edit-distance 2 and all_words
    """
    return {w
            for e1 in edit1(word)
            for w in edit1(e1)} & all_words


def read_all_words(path):
    """
    reads all words of a given dictionary
    and returns them as a set

    :param path: path to dictionary file
    :return: words as set
    """
    with open(path) as f:
        return {line.strip().lower()
                for line in f
                }


def correct(word, wordlist):
    """
    either the word is in the dictionary => the word
    or there's at least one word with edit-distance 1 in the dictionary => the list
    or there's at least one word with edit-distance 2 in the dictionary => the list
    otherwise I have no idea => the word

    >>> woerter = read_all_words("/usr/share/dict/german")
    >>> correct("Papier", woerter)
    {'papier'}
    >>> correct("Papirr", woerter)
    {'papier'}
    >>> sorted(correct("papir", woerter))
    ['papi', 'papier']

    :param word: given word string
    :param wordlist: words in the dictionary
    :return:
    """
    word = word.lower()
    return ({word} & wordlist) or edit1_good(word, wordlist) or edit2_good(word, wordlist) or {word}
