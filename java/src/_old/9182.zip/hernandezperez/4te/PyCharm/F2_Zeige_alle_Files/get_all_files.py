import os


def get_all_files(pathname):
    """
    searches the given pathname for all 'real' files (no dirs no links) recursively
    :param pathname: directory to start from
    :return: all real files
    """
    d = os.listdir(pathname)
    for f in d:
        new_path = pathname + f
        if os.path.isdir(new_path):
            yield from get_all_files(new_path + "/")
        if os.path.isfile(new_path):
            yield new_path


for test in get_all_files("/home/hp/Documents/"):
    print(test)

