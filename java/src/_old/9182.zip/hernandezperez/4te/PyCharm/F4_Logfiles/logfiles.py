import os
import re
import zipfile
from collections import defaultdict
from collections.abc import Generator


def get_all_files(path: os.PathLike | str) -> Generator[str, None, None]:
    """
    searches the given pathname for all 'real' files (no dirs no links) recursively
    :param path: directory to start from
    :return: all real files
    """
    if os.path.isfile(path):
        yield path
        return
    d = os.listdir(path)
    for f in d:
        new_path = path + f
        if os.path.isdir(new_path):
            try:
                yield from get_all_files(new_path + "/")
            except PermissionError:
                print("Permission denied: ", new_path)
        if os.path.isfile(new_path):
            yield new_path


def open_files(filenames):
    """
    the given files and yields their contents
    :param filenames: files to open
    :return:
    """
    for fn in filenames:
        try:
            with zipfile.ZipFile(fn, 'r') as zip_ref:
                for zf in zip_ref.namelist():
                    yield from open_file(zf)
        except zipfile.BadZipfile:
            print("Not a Zip File")
        yield from open_file(fn)


def open_file(file):
    with open(file, mode="r", encoding="iso-8859-1") as f:
        yield f


def read_lines(files):
    """
    reads all lines of all given files
    :param files: given files
    :return: yield line
    """
    for f in files:
        for line in f:
            yield line


def print_lines(lines):
    """
    strips and prints all given lines
    :param lines: given lines
    :return: -
    """
    for line in lines:
        print(line.rstrip())


def long_lines(lines, length):
    """
    yields all lines longer than the given length
    :param lines: given lines
    :param length: min line length
    :return: yield line
    """
    for line in lines:
        if len(line) > length:
            yield line


def words(lines):
    """
    yields all words of all given lines
    :param lines: given lines
    :return: yield word
    """
    for line in lines:
        for word in line.split():
            yield word


def grep(lines, pattern, n):
    """
    yield all lines matching the given pattern
    :param lines: given lines
    :param pattern: given pattern
    :param n: group
    :return: yield line
    """
    for line in lines:
        m = re.search(pattern, line)
        if m is None:
            continue
        yield m.group(n)


# TODO rework maybe
def wc(files):
    """
    print row/word/char count of given files
    :param files: given files
    :return: -
    """
    for file in files:
        num_rows = 0
        num_words = 0
        num_chars = 0
        for line in file:
            num_words += len(line.split())
            for c in line:
                num_chars += 1
            num_rows += 1
        print(file.name, ':', num_rows, num_words, num_chars)


def head(files, n):
    """
    print the first n rows of all given files
    :param files: given files
    :param n: number of lines
    :return: -
    """
    for file in files:
        counter = 0
        for line in file:
            if counter == n:
                break
            counter += 1
            yield line.strip()


def tail(files, n):
    """
    print the last n lines of all given files
    :param files: given files
    :param n: number of lines
    :return: -
    """
    for file in files:
        counter = 0
        for line in reversed(list(file)):
            if counter == n:
                break
            counter += 1
            yield line.strip()


def select():
    pass


def sum():
    pass


def topIP():
    global fileName, fl, of
    # ===Welcher Rechner(IP-Adresse) surft am meisten?===
    fileName = "/home/hp/Documents/Schule/4te_Klasse/SEW4/Angaben/05_python/access_log/access.log"
    fl = get_all_files(fileName)
    of = open_files(fl)
    ipDict = defaultdict(int)
    for ip in grep(read_lines(of), r"\b(?:\d{1,3}\.){3}\d{1,3}\b", 0):
        ipDict[ip] += 1
    print("Am meisten surfender Rechner:", max(zip(ipDict.values(), ipDict.keys())))


def topSite():
    global fl, of
    # ===Welche Seite wird am öftesten aufgerufen?===
    fl = get_all_files(fileName)
    of = open_files(fl)
    siteDict = defaultdict(int)
    for site in grep(read_lines(of), r"\"GET ([^\s]*)", 1):
        siteDict[site] += 1
    print("Am meisten besuchte Seite:", max(zip(siteDict.values(), siteDict.keys())))


def sumAllBytes():
    global fl, of
    # ===Wie viele Bytes wurden übertragen?===
    fl = get_all_files(fileName)
    of = open_files(fl)
    sumBytes = 0
    for nbytes in grep(read_lines(of), r"\d+ (\d+)", 1):
        if nbytes:
            sumBytes += int(nbytes)
    print("Uebertragene Bytes:", sumBytes)


if __name__ == '__main__':
    # zf = get_all_files("/home/hp/Documents/Schule/4te_Klasse/SEW4/Angaben/05_python/access_log/access_log.zip")
    # zof = open_files(zf)
    # for lines in zof:
    #     print_lines(lines)
    list(get_all_files("/etc/"))
    # print_lines(read_lines(zf))
    # topIP()
    # topSite()
    # sumAllBytes()

