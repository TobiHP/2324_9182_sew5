useradd  -d /home/klassen/k1cm -c k1cm -m  -g k1cm -G cdrom,plugdev,sambashare -s /bin/bash k1cm
echo k1cm:k1cm\%379\^GRM\^ | chpasswd

useradd  -d /home/klassen/k2am -c k2am -m  -g k2am -G cdrom,plugdev,sambashare -s /bin/bash k2am
echo k2am:k2am\%359\)TMP\& | chpasswd

useradd  -d /home/klassen/k2bm -c k2bm -m  -g k2bm -G cdrom,plugdev,sambashare -s /bin/bash k2bm
echo k2bm:k2bm\-376\,WIT\! | chpasswd

useradd  -d /home/klassen/k2cm -c k2cm -m  -g k2cm -G cdrom,plugdev,sambashare -s /bin/bash k2cm
echo k2cm:k2cm\-275\&PCH\) | chpasswd

useradd  -d /home/klassen/k3am -c k3am -m  -g k3am -G cdrom,plugdev,sambashare -s /bin/bash k3am
echo k3am:k3am\(375\_ZOI\_ | chpasswd

useradd  -d /home/klassen/k3bm -c k3bm -m  -g k3bm -G cdrom,plugdev,sambashare -s /bin/bash k3bm
echo k3bm:k3bm\^361\^KAM\& | chpasswd

useradd  -d /home/klassen/k3cm -c k3cm -m  -g k3cm -G cdrom,plugdev,sambashare -s /bin/bash k3cm
echo k3cm:k3cm\,377\#PRS\- | chpasswd

useradd  -d /home/klassen/k4am -c k4am -m  -g k4am -G cdrom,plugdev,sambashare -s /bin/bash k4am
echo k4am:k4am\#154\)MAR\! | chpasswd

useradd  -d /home/klassen/k4bm -c k4bm -m  -g k4bm -G cdrom,plugdev,sambashare -s /bin/bash k4bm
echo k4bm:k4bm\,263\%GRI\) | chpasswd

useradd  -d /home/klassen/k4cm -c k4cm -m  -g k4cm -G cdrom,plugdev,sambashare -s /bin/bash k4cm
echo k4cm:k4cm\^279\-BUG\) | chpasswd

useradd  -d /home/klassen/k5am -c k5am -m  -g k5am -G cdrom,plugdev,sambashare -s /bin/bash k5am
echo k5am:k5am\=156\=PLE\( | chpasswd

useradd  -d /home/klassen/k5bm -c k5bm -m  -g k5bm -G cdrom,plugdev,sambashare -s /bin/bash k5bm
echo k5bm:k5bm\&160\-STW\# | chpasswd

useradd  -d /home/klassen/k5cm -c k5cm -m  -g k5cm -G cdrom,plugdev,sambashare -s /bin/bash k5cm
echo k5cm:k5cm\!354\-JEN\( | chpasswd

useradd  -d /home/klassen/k1af -c k1af -m  -g k1af -G cdrom,plugdev,sambashare -s /bin/bash k1af
echo k1af:k1af\^372\%GFO\. | chpasswd

useradd  -d /home/klassen/k1bf -c k1bf -m  -g k1bf -G cdrom,plugdev,sambashare -s /bin/bash k1bf
echo k1bf:k1bf\.272\#VOL\& | chpasswd

useradd  -d /home/klassen/k1cf -c k1cf -m  -g k1cf -G cdrom,plugdev,sambashare -s /bin/bash k1cf
echo k1cf:k1cf\=209\%KEG\# | chpasswd

useradd  -d /home/klassen/k2af -c k2af -m  -g k2af -G cdrom,plugdev,sambashare -s /bin/bash k2af
echo k2af:k2af\%357\(BOG\= | chpasswd

useradd  -d /home/klassen/k2bf -c k2bf -m  -g k2bf -G cdrom,plugdev,sambashare -s /bin/bash k2bf
echo k2bf:k2bf\,219\%STE\% | chpasswd

useradd  -d /home/klassen/k3afi -c k3afi -m  -g k3afi -G cdrom,plugdev,sambashare -s /bin/bash k3afi
echo k3afi:k3afi\-356\,HIT\! | chpasswd

useradd  -d /home/klassen/k3bfn -c k3bfn -m  -g k3bfn -G cdrom,plugdev,sambashare -s /bin/bash k3bfn
echo k3bfn:k3bfn\.277\#BAA\= | chpasswd

useradd  -d /home/klassen/k4afi -c k4afi -m  -g k4afi -G cdrom,plugdev,sambashare -s /bin/bash k4afi
echo k4afi:k4afi\!275/279\#OPP\= | chpasswd

useradd  -d /home/klassen/k4bfn -c k4bfn -m  -g k4bfn -G cdrom,plugdev,sambashare -s /bin/bash k4bfn
echo k4bfn:k4bfn\#217\!CER\. | chpasswd

useradd  -d /home/klassen/k1ai -c k1ai -m  -g k1ai -G cdrom,plugdev,sambashare -s /bin/bash k1ai
echo k1ai:k1ai\#254\,KLE\, | chpasswd

useradd  -d /home/klassen/k1bi -c k1bi -m  -g k1bi -G cdrom,plugdev,sambashare -s /bin/bash k1bi
echo k1bi:k1bi\^371\!HOL\- | chpasswd

useradd  -d /home/klassen/k1ci -c k1ci -m  -g k1ci -G cdrom,plugdev,sambashare -s /bin/bash k1ci
echo k1ci:k1ci\&265\=JAV\! | chpasswd

useradd  -d /home/klassen/k2ai -c k2ai -m  -g k2ai -G cdrom,plugdev,sambashare -s /bin/bash k2ai
echo k2ai:k2ai\=378\!BAY\. | chpasswd

useradd  -d /home/klassen/k2bi -c k2bi -m  -g k2bi -G cdrom,plugdev,sambashare -s /bin/bash k2bi
echo k2bi:k2bi\)363\#KUS\! | chpasswd

useradd  -d /home/klassen/k2ci -c k2ci -m  -g k2ci -G cdrom,plugdev,sambashare -s /bin/bash k2ci
echo k2ci:k2ci\,271\&NIC\% | chpasswd

useradd  -d /home/klassen/k3ai -c k3ai -m  -g k3ai -G cdrom,plugdev,sambashare -s /bin/bash k3ai
echo k3ai:k3ai\.260\.BUC\! | chpasswd

useradd  -d /home/klassen/k3bi -c k3bi -m  -g k3bi -G cdrom,plugdev,sambashare -s /bin/bash k3bi
echo k3bi:k3bi\_360\.BSB\, | chpasswd

useradd  -d /home/klassen/k3ci -c k3ci -m  -g k3ci -G cdrom,plugdev,sambashare -s /bin/bash k3ci
echo k3ci:k3ci\_225\)BRE\_ | chpasswd

useradd  -d /home/klassen/k4ai -c k4ai -m  -g k4ai -G cdrom,plugdev,sambashare -s /bin/bash k4ai
echo k4ai:k4ai\^261\_DAZ\= | chpasswd

useradd  -d /home/klassen/k4bi -c k4bi -m  -g k4bi -G cdrom,plugdev,sambashare -s /bin/bash k4bi
echo k4bi:k4bi\#257\-OLI\) | chpasswd

useradd  -d /home/klassen/k4cn -c k4cn -m  -g k4cn -G cdrom,plugdev,sambashare -s /bin/bash k4cn
echo k4cn:k4cn\-276\=SDO\! | chpasswd

useradd  -d /home/klassen/k5ax -c k5ax -m  -g k5ax -G cdrom,plugdev,sambashare -s /bin/bash k5ax
echo k5ax:k5ax\_278\,FIN\_ | chpasswd

useradd  -d /home/klassen/k5bi -c k5bi -m  -g k5bi -G cdrom,plugdev,sambashare -s /bin/bash k5bi
echo k5bi:k5bi\%256\#NUS\# | chpasswd

useradd  -d /home/klassen/k5cn -c k5cn -m  -g k5cn -G cdrom,plugdev,sambashare -s /bin/bash k5cn
echo k5cn:k5cn\&259\^SLT\= | chpasswd

useradd  -d /home/klassen/k1ao -c k1ao -m  -g k1ao -G cdrom,plugdev,sambashare -s /bin/bash k1ao
echo k1ao:k1ao\(217\_KIT\( | chpasswd

useradd  -d /home/lehrer -c lehrer -m  -g lehrer -G cdrom,plugdev,sambashare -s /bin/bash lehrer
useradd  -d /home/lehrer -c seminar -m  -g seminar -G cdrom,plugdev,sambashare -s /bin/bash seminar
