package u02_Labyrinth;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

/**
 * a class used to solve a labyrinth puzzle
 *
 * @author Tobias Hernandez Perez, 5CN
 */
public class Labyrinth {
    public static String[][] maps = {{
            "############",
            "#  #     # #",
            "## # ### # #",
            "#  # # # # #",
            "## ### # # #",
            "#        # #",
            "## ####### #",
            "#          #",
            "# ######## #",
            "# #   #    #",
            "#   #   # ##",
            "######A#####"
    }, {
            "################################",
            "#                              #",
            "# ############################ #",
            "# # ###       ##  #          # #",
            "# #     ##### ### # ########## #",
            "# #   ##### #     # #      ### #",
            "# # ##### #   ###   # # ## # # #",
            "# # ### # ## ######## # ##   # #",
            "# ##### #  # #   #    #    ### #",
            "# # ### ## # # # # ####### # # #",
            "# #        # #   #     #     # #",
            "# ######## # ######### # ### # #",
            "# ####     #  # #   #  # ##### #",
            "# # #### #### # # # # ## # ### #",
            "#                      # #     #",
            "###########################A####"
    }, {
            "###########################A####",
            "#   #      ## # # ###  #     # #",
            "# ###### #### # # #### ##### # #",
            "# # ###  ## # # # #          # #",
            "# # ### ### # # # # # #### # # #",
            "# #     ### # # # # # ## # # # #",
            "# # # # ### # # # # ######## # #",
            "# # # #     #          #     # #",
            "# ### ################ # # # # #",
            "# #   #             ## # #   # #",
            "# # #### ############# # #   # #",
            "# #                    #     # #",
            "# # #################### # # # #",
            "# # #### #           ###     # #",
            "# # ## # ### ### ### ### # ### #",
            "# #    #     ##  ##  # ###   # #",
            "# ####   ###### #### # ###  ## #",
            "###########################A####"
    }
    };

    /**
     * Wandelt (unveränderliche) Strings in Char-Arrays
     *
     * @param map der Plan, ein String je Zeile
     * @return char[][] des Plans
     */
    public static char[][] fromStrings(String[] map) {
        char[][] charMap = new char[map.length][map[0].length()];

        for (int row = 0; row < map.length; row++) {
            charMap[row] = map[row].toCharArray();
        }

        return charMap;
    }


    /**
     * Ausgabe des Layrinths
     *
     * @param lab
     */
    public static void printLabyrinth(char[][] lab) {
        for (char[] row : lab) {
            System.out.println(new String(row));
        }
    }

    /**
     * Suche den Weg
     *
     * @param zeile  aktuelle Position
     * @param spalte aktuelle Position
     * @param lab
     * @throws InterruptedException für die verlangsamte Ausgabe mit sleep()
     */
    public static boolean suchen(int zeile, int spalte, char[][] lab) throws InterruptedException {
        if (lab[zeile][spalte] == 'A') {
            return true;
        } else if (lab[zeile][spalte] == '#' || lab[zeile][spalte] == 'x') {
            return false;
        }

        lab[zeile][spalte] = 'x';

//        printLabyrinth(lab);
//        System.out.println();
//
//        Thread.sleep(1000);

        return suchen(zeile, spalte + 1, lab) ||  // rechts
                suchen(zeile, spalte - 1, lab) ||  // links
                suchen(zeile - 1, spalte, lab) ||  // oben
                suchen(zeile + 1, spalte, lab); // unten
    }

    /**
     * Suche alle Wege durch das Labyrinth
     *
     * @param zeile  aktuelle y Position
     * @param spalte aktuelle x Position
     * @param lab    das Labyrinth als char Array
     * @return Anzahl an Wegen durch das Labyrinth
     */
    private static int suchenAlle(int zeile, int spalte, char[][] lab) {
        int anzWege = 0;

        if (lab[zeile][spalte] == 'A') {
//            printLabyrinth(lab);
//            System.out.println();
            return 1;
        } else if (lab[zeile][spalte] != ' ') {
            return 0;
        }

        lab[zeile][spalte] = 'x';

        anzWege += suchenAlle(zeile, spalte + 1, lab) + // rechts
                suchenAlle(zeile, spalte - 1, lab) + // links
                suchenAlle(zeile + 1, spalte, lab) + // oben
                suchenAlle(zeile - 1, spalte, lab); // unten

        lab[zeile][spalte] = ' ';

        return anzWege;
    }

    /**
     * Liest ein File in ein Labyrinth char Array ein
     *
     * @param path der Plan, ein String je Zeile
     * @return char[][] des Plans
     */
    public static char[][] fromFile(String path) {
        try {
            String[] stringMap = Files.readString(Paths.get(path)).trim().split("\n");

            return fromStrings(stringMap);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws InterruptedException {
//        System.out.println("Labyrinth Ausgang gefunden: " + (suchen(5, 5, fromStrings(maps[3])) ? "ja" : "nein"));
//
        int counter = 0;
//
//        // simple suche
//        for (String[] map : maps) {
//            System.out.println("Labyrinth " + counter + " Ausgang gefunden: " + (suchen(5, 5, fromStrings(map)) ? "ja" : "nein"));
//            counter++;
//        }

//        counter = 0;


//        // komplexe suche
//        for (String[] map : maps) {
//            System.out.println("Labyrinth " + counter + " Anzahl Wege: " + suchenAlle(5, 5, fromStrings(map)));
//            counter++;
//        }

//        System.out.println("\n=====File lesen");
//
//        // file lesen
        long t0 = System.currentTimeMillis();
        char[][] l1 = fromFile("res/l1.txt");
        char[][] l2 = fromFile("res/l2.txt");
        char[][] l3 = fromFile("res/l3.txt");
//        printLabyrinth(labyrinth);
//
        System.out.println("Anzahl Wege l1: " + suchenAlle(5, 5, l1));
        System.out.println("Anzahl Wege l2: " + suchenAlle(5, 5, l2));
        System.out.println("Anzahl Wege l3: " + suchenAlle(5, 5, l3));
        System.out.println("Time take: " + (System.currentTimeMillis() - t0) + "ms");
    }
}
